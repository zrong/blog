<?php

/**
* a6FlashMamBot 1.3
* Allows inserting flash animations in Mambo Content
* (C) active6 2005
*
* 修改：zengrong.net 2006-09-06
* 使用swfobject1.42加载Flash文件，支持所有的swfobject参数
* <b>Usage:</b>
* {flash file="filename.swf" width="200" height= "100" align="left" bgcolor="FFFFFF" base="images/flash/ quality="high" play="true" loop="true" menu="false"}
*
**/

defined('_VALID_MOS') or die('Direct Access to this location is not allowed.');

//error_reporting(E_ALL);

$_MAMBOTS->registerFunction('onPrepareContent', 'botMosFlash');

function botMosFlash($published, &$row, $mask = 0, $page = 0)
{
	global $mosConfig_absolute_path;
	
	if(!$published)
	{
		return true;
	}

	require_once($mosConfig_absolute_path.'/includes/domit/xml_saxy_lite_parser.php');

	$regex = "#{flash*(.*?)}#s";

	$row->text = preg_replace_callback($regex, 'botMosFlash_replacer', $row->text);

	return true;
}

function botMosFlash_replacer(&$matches)
{
	global $database;
	global $mosConfig_live_site;

	$defquality = 'high';
	$defpath = 'images/stories/';
	$defalign = 'left';
	$defplay = "true";
	$defloop = "true";
	$defmenu = "false";
	$defversion = "7";

	$database->setQuery("SELECT id FROM #__mambots WHERE element = 'a6mamboflash' AND folder = 'content'");
	$id = $database->loadResult();
	$mambot = new mosMambot($database);
	$mambot->load($id);
	$mambotParams =& new mosParameters($mambot->params);

	$defquality = $mambotParams->def('quality', $defquality );
	$defpath = $mambotParams->def('path', $defpath );
	$defalign = $mambotParams->def('align', $defalign);	
	$defplay = $mambotParams->def('play', $defplay);
	$defloop = $mambotParams->def('loop', $defloop);
	$defmenu = $mambotParams->def('menu', $defmenu);
	$defversion = $mambotParams->def('version', $defversion);

	$parseit = html_entity_decode( $matches[1] );
	$attribs = @SAXY_Lite_Parser::parseAttributes($parseit);
	
	$filename = @$attribs['file'];
	$width = @$attribs['width'];
	$height = @$attribs['height'];
	$bgcolor = @$attribs['bgcolor'];
	$fversion = @$attribs['version'];
	$scale = @$attribs['scale'];
	$wmode = @$attribs['wmode'];
	$base = @$attribs['base'];
	$allowScriptAccess = @$attribs['allowScriptAccess'];
	$FlashVars = @$attribs['FlashVars'];
	$xiRedirectUrl = @$attribs['xiRedirectUrl'];
	$useExpressInstall = @$attribs['useExpressInstall'];
	$redirectUrl = @$attribs['redirectUrl'];

	//设置默认的参数
	$quality = $defquality;
	if(array_key_exists('quality', $attribs))
	{
		$quality = @$attribs['quality'];
	}

	$align = $defalign;
	if(array_key_exists('align', $attribs))
	{
		$align = @$attribs['align'];
	}

	$flashpath = append_slash_if_none($defpath);
	if(array_key_exists('path', $attribs))
	{
		$flashpath = append_slash_if_none(@$attribs['path']);
	}

	$play = $defplay;
	if(array_key_exists('play', $attribs))
	{
		$play = @$attribs['play'];
	}

	$loop = $defloop;
	if(array_key_exists('loop', $attribs))
	{
		$loop = @$attribs['loop'];
	}

	$menu = $defmenu;
	if(array_key_exists('menu', $attribs))
	{
		$menu = @$attribs['menu'];
	}
	$fversion = $defversion;
	if(array_key_exists('version', $attribs))
	{
		$fversion = @$attribs['version'];
	}

	$results = '<script src="' . $mosConfig_live_site . '/mambots/content/swfobject.js" type="text/javascript"></script>' . "\n";
	$results .= '<div id="flashdiv_' . $filename . '"></div>' . "\n";
	$results .= '<script type="text/javascript">' . "\n";
	$results .= '// <![CDATA[' . "\n";
	$results .= 'var so = new SWFObject("' . $flashpath.$filename . '", "' . 'a6mamboflash_'.$filename . '", "' . $width . '", "' . $height . '", "' . $fversion . '", "' . $bgcolor . '");' . "\n";
	//
	$results .= createParam('align', $align);
	$results .= createParam('play', $play);
	$results .= createParam('loop', $loop);
	$results .= createParam('menu', $menu);
	$results .= createParam('scale', $scale);
	$results .= createParam('wmode', $wmode);
	$results .= createParam('base', $base);
	$results .= createParam('allowScriptAccess', $allowScriptAccess);
	//
	$results .= createAttribute('xiRedirectUrl', $xiRedirectUrl);
	$results .= createAttribute('useExpressInstall', $useExpressInstall);
	$results .= createAttribute('redirectUrl', $redirectUrl);
	$results .= createVariable($FlashVars);
	//
	$results .= 'so.write("flashdiv_' . $filename .'");' . "\n";
	$results .= '// ]]>' . "\n";
	$results .= '</script>' . "\n";
	return $results;
}

function createAttribute($attributename, $value)
{
	if(empty($value)){
		return "";
	}else{
		if($attributename == 'useExpressInstall'){
			$value2 = $value;
		}else{
			$value2 = '"' . $value . '"';
		}
		return 'so.setAttribute("' . $attributename . '", ' . $value2 . ');' . "\n";
	}
}

function createVariable($fvars)
{
	$fvarpair_regex		= "/(?<!([$|\?]\{))\s+;\s+(?!\})/";
	$flashvars = (!empty($fvars)) ? preg_split($fvarpair_regex, $fvars, -1, PREG_SPLIT_NO_EMPTY) : array();
	$allvar = '';
	for ($i = 0; $i < count($flashvars); $i++) {
		$thispair	= trim($flashvars[$i]);
		$nvpair		= explode("=",$thispair);
		$name		= trim($nvpair[0]);
		$value		= trim($nvpair[1]);
		// Prune out JS or PHP values
		if (preg_match("/^\\$\\{.*\\}/i", $value)) { 		// JS
			$endtrim 	= strlen($value) - 3;
			$value		= substr($value, 2, $endtrim);
			$value		= str_replace(';', '', $value);
		} else if (preg_match("/^\\?\\{.*\\}/i", $value)) {	// PHP
			$endtrim 	= strlen($value) - 3;
			$value 		= substr($value, 2, $endtrim);
			$value 		= '"'.eval("return " . $value).'"';
		} else {
			$value = '"'.$value.'"';
		}
		$allvar .= 'so.addVariable("' . $name . '", ' . $value . ');' . "\n";
	}
	return $allvar;
}

function createParam($paramname, $value)
{
	if(empty($value))
	return "";
	else
	return 'so.addParam("' . $paramname . '", "' . $value . '");' . "\n";
}

function append_slash_if_none($string)
{
	if (ereg ("/$", $string))
	{
		return $string;
	}
	else
	{
		return ereg_replace("$", "/", $string);
	}
}
?>