a6MamboFlash Bot 1.2
====================
This Mambot is now compatible with Mambo 4.5.2, and allows adding Flash animations to your content.

If the Flash player is not installed on the user's machine, it will attempt to install it in the background. The Flash Player referred is the last general distribution (6.0.24).

This player should already be present on most systems. The syntax and options have been brought in line with the options provided in the Flash 6 player.

Usage
=====
After installing the Mambot, simply add the tag into your content with the following syntax:

{flash file="filename.swf" width="999" height="999" align="left" background="FFFFFF"path="images/stories/"  quality="high" play="true" loop="true" menu="false"}

All options are shown with their default value  (except file, width and height). Options with a default value can be omitted; the order of options specified is not important. The possible values for the options are:

    * file: the filename of the Flash .swf animation file.


    * width, height: the dimensions of the animations. If these do not correspond with the actual dimensions of the generated flash file, the animation will be resized to match the given dimensions.


    * align: alignment, same as for the mosImage Mambot. Defaults to left.


    * background: hexadecimal RGB value for the background color of the animation. Defaults to white.


    * quality: best, high, medium, low, autohigh or autolow. See the Macromedia Flash documentation for details. Defaults to high.


    * path: the URL to the folder where the flash file is stored. Defaults to images/stories/


    * play: start playing the animation, or stop at the first frame. Defaults to true.


    * loop: loop the animation. Defaults to true.


    * menu: show extended Flash menu on right-click over the animation. Defaults to false.
