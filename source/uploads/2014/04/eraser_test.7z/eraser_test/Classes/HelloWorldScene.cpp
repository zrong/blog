#include "HelloWorldScene.h"

USING_NS_CC;

CCScene* HelloWorld::scene()
{
    // 'scene' is an autorelease object
    CCScene *scene = CCScene::create();
    
    // 'layer' is an autorelease object
    HelloWorld *layer = HelloWorld::create();

    // add layer as a child to scene
    scene->addChild(layer);

    // return the scene
    return scene;
}

// on "init" you need to initialize your instance
bool HelloWorld::init()
{
    //////////////////////////////
    // 1. super init first
    if ( !CCLayer::init() )
    {
        return false;
    }
    
    CCSize visibleSize = CCDirector::sharedDirector()->getVisibleSize();
    CCPoint origin = CCDirector::sharedDirector()->getVisibleOrigin();

	this->setTouchMode(kCCTouchesOneByOne);
	this->setTouchEnabled(true);

    /////////////////////////////
    // 2. add a menu item with "X" image, which is clicked to quit the program
    //    you may modify it.

    // add a "close" icon to exit the progress. it's an autorelease object
    CCMenuItemImage *pCloseItem = CCMenuItemImage::create(
                                        "CloseNormal.png",
                                        "CloseSelected.png",
                                        this,
                                        menu_selector(HelloWorld::menuCloseCallback));
    
	pCloseItem->setPosition(ccp(origin.x + visibleSize.width - pCloseItem->getContentSize().width/2 ,
                                origin.y + pCloseItem->getContentSize().height/2));

    // create menu, it's an autorelease object
    CCMenu* pMenu = CCMenu::create(pCloseItem, NULL);
    pMenu->setPosition(CCPointZero);
    this->addChild(pMenu, 1);

    /////////////////////////////
    // 3. add your codes below...

	CCPoint center = ccp(visibleSize.width / 2 + origin.x, visibleSize.height / 2 + origin.y);
    CCSprite* pSprite = CCSprite::create("HelloWorld.png");
    pSprite->setPosition(center);
    this->addChild(pSprite, 0);

	pEraser = CCDrawNode::create();
	pEraser->drawDot(ccp(0, 0), 20, ccc4f(0, 0, 0, 0));
	pEraser->retain();

	pRTex = CCRenderTexture::create(visibleSize.width, visibleSize.height);
	pRTex->setPosition(ccp(visibleSize.width/2, visibleSize.height/2));
	this->addChild(pRTex, 10);

	CCSprite* pBg = CCSprite::create("dirt.png");
	pBg->setAnchorPoint(ccp(0.5,0.5));
	pBg->setPosition(center);
	pRTex->begin();
	pBg->visit();
	pRTex->end();
	
    return true;
}

bool HelloWorld::ccTouchBegan(CCTouch* touch, CCEvent* event)
{
	return true;
}

void HelloWorld::ccTouchMoved(CCTouch* touch, CCEvent* event)
{
	CCPoint touchPoint = touch->getLocation();
	
	pEraser->setPosition(touchPoint);
	eraseByBlend();
	//eraseByColorMask();

	//CCLOG("(%f, %f)", touchPoint.x, touchPoint.y);
}

void HelloWorld::eraseByBlend()
{
	ccBlendFunc blendFunc = { GL_ONE, GL_ZERO };
	pEraser->setBlendFunc(blendFunc);
	pRTex->begin();
	pEraser->visit();
	pRTex->end();
}

void HelloWorld::eraseByColorMask()
{
	//ccBlendFunc blendFunc = { GL_ZERO, GL_ZERO };
	//pEraser->setBlendFunc(blendFunc);
	pRTex->begin();
	glColorMask(GL_FALSE, GL_FALSE, GL_FALSE, GL_TRUE);
	pEraser->visit();
	glColorMask(GL_TRUE, GL_TRUE, GL_TRUE, GL_TRUE);
	pRTex->end();
}

void HelloWorld::menuCloseCallback(CCObject* pSender)
{
	CC_SAFE_RELEASE(pEraser);
#if (CC_TARGET_PLATFORM == CC_PLATFORM_WINRT) || (CC_TARGET_PLATFORM == CC_PLATFORM_WP8)
	CCMessageBox("You pressed the close button. Windows Store Apps do not implement a close button.","Alert");
#else
    CCDirector::sharedDirector()->end();
#if (CC_TARGET_PLATFORM == CC_PLATFORM_IOS)
    exit(0);
#endif
#endif
}
