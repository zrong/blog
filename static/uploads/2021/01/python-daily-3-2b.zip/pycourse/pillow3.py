#==========================================
# 曾老师的 Python 课
# 课程地址：https://blog.zengrong.net/tag/pythoncouse/
# 课程内容：2021-01-19 pillow 修改图像
# resize 文档： https://pillow.readthedocs.io/en/latest/reference/Image.html#PIL.Image.Image.resize
# rotate 文档： https://pillow.readthedocs.io/en/latest/reference/Image.html#PIL.Image.Image.rotate
#==========================================

from pathlib import Path
from PIL import Image

# 当前文件所在文件夹
basedir = Path(__file__).parent


def get_file(name, suffix):
    """ 返回 assets 文件夹下的原始文件和目标文件

    :param name: 原始文件名
    :param suffix: 需要被增加到目标文件名中的后缀
    :returns: 原始文件，目标文件
    """
    sfile = basedir.joinpath('assets', name)
    # 假设 name 的值为 '前台.jpg' ，我们需要分别得到 '前台' 和 'jpg' 两个字符串，此时需要使用 split 方法，基于英文句号将字符串拆成两个
    # sfile.name.split('.') 会返回一个 list，包含两个字符串。fname 和 fext 中分别包含 '前台' 和 'jpg' 这两个值
    fname, fext = sfile.name.split('.')

    # 使用 f 开头的字符串支持替换，下面的 suffix 等花括号中的变量会自动被替换为变量中的值
    # 架设 suffix 的值为 'rotate90'，那么 tfilename 的值为 '前台_rotate90.jpg'
    tfilename = f'{fname}_{suffix}.{fext}'
    tfile = basedir.joinpath('assets', tfilename)

    # 返回原始文件和目标文件
    return sfile, tfile


def rotate(source_name, angle):
    """ 旋转 source 图像文件到 angle 角度，并保存到新文件

    :param source_name: 原始文件名
    :param angle: 浮点数，旋转的角度。90 代表顺时针旋转 90 度
    """
    # 获得原始文件和目标文件，其中 f 字符串的用法在 get_file 中介绍了
    sfile, tfile = get_file(source_name, f'rotate{angle}')

    simg = Image.open(sfile)
    timg = simg.rotate(angle)
    timg.save(tfile)


def scale(source_name, ratio):
    """ 改变 source 图像大小，使用 ratio 作为比例，保存到新文件
    
    :param source_name: 原始文件名
    :param ratio: 浮点数，代表调整的比例。 0.5 代表调整为原始大小的 50%
    """
    # 获得原始文件和目标文件，其中 f 字符串的用法在 get_file 中介绍了
    sfile, tfile = get_file(source_name, f'rotate{ratio}')

    simg = Image.open(sfile)

    # 获取图像调整后的大小，使用 int 来将浮点数转换成整数
    width = int(simg.width * ratio)
    height = int(simg.height * ratio)

    # (width, height) 是一个参数，同时提供两个值
    timg = simg.resize((width, height))
    timg.save(tfile)


# 把 前台.jpg 这个文件旋转 90 度
rotate('前台.jpg', 90)

# 把 前台.jpg 这个文件缩小 50%
scale('前台.jpg', 0.5)

# 把 餐厅.jpg 这个文件旋转 180 度
rotate('餐厅.jpg', 180)