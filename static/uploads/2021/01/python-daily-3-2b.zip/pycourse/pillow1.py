# 曾老师的 Python 课
# 课程地址：https://blog.zengrong.net/tag/pythoncouse/
# 课程内容：2021-01-18 pillow 高斯模糊滤镜
# 高斯模糊滤镜文档： https://pillow.readthedocs.io/en/4.1.x/reference/ImageFilter.html#PIL.ImageFilter.GaussianBlur

from pathlib import Path
from PIL import Image
from PIL.ImageFilter import GaussianBlur

# 当前文件所在文件夹
basedir = Path(__file__).parent

# 原始图像文件
sfile = basedir.joinpath('assets/餐厅.jpg')
# 目标图像文件
tfile = basedir.joinpath('assets/餐厅_高斯模糊_10.jpg')

# 创建一个高斯模糊滤镜对象，模糊半径为 10
gb = GaussianBlur(radius=10)

# 打开原始图像
simg = Image.open(sfile)
# 对原始图像文件使用滤镜，返回一个目标图像
timg = simg.filter(gb)

# 将应用过滤镜的图像文件保存到目标图像文件中
timg.save(tfile)